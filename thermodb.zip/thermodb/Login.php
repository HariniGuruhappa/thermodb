<?php
// Start the session
session_start();
?>
<?php   include('mainHeader.php');  ?>
<style>

   
body {
  width:100%;
    height:100%;
}

.card-signin {
  border: 0;
  border-radius: 1rem;
  box-shadow: 0 0.5rem 1rem 0 rgba(0, 0, 0, 0.1);
}

.card-signin .card-title {
  margin-bottom: 2rem;
  font-weight: 300;
  font-size: 1.5rem;
margin-top: 20%;
}

.card-signin .card-body {
  padding: 3rem;
}

.form-signin {
  width: 100%;
}

.form-signin .btn {
  font-size: 80%;
  border-radius: 5rem;
  letter-spacing: .1rem;
  font-weight: bold;
  padding: 1rem;
  transition: all 0.2s;
}

.form-label-group {
  position: relative;
  margin-bottom: 1rem;
}

.form-label-group input {
  height: auto;
  border-radius: 2rem;
}

.form-label-group>input,
.form-label-group>label {
  padding: var(--input-padding-y) var(--input-padding-x);
}

.form-label-group>label {
  position: absolute;
  top: 0;
  left: 0;
  display: block;
  width: 100%;
  margin-bottom: 0;
  /* Override default `<label>` margin */
  line-height: 1.5;
  color: #495057;
  border: 1px solid transparent;
  border-radius: .25rem;
  transition: all .1s ease-in-out;
}
/*
.form-label-group input::-webkit-input-placeholder {
  color: transparent;
}

.form-label-group input:-ms-input-placeholder {
  color: transparent;
}

.form-label-group input::-ms-input-placeholder {
  color: transparent;
}

.form-label-group input::-moz-placeholder {
  color: transparent;
}

.form-label-group input::placeholder {
  color: transparent;
}
*/
.form-label-group input:not(:placeholder-shown) {
  padding-top: calc(var(--input-padding-y) + var(--input-padding-y) * (2 / 3));
  padding-bottom: calc(var(--input-padding-y) / 3);
}

.form-label-group input:not(:placeholder-shown)~label {
  padding-top: calc(var(--input-padding-y) /2);
  padding-bottom: calc(var(--input-padding-y) / 2);
  font-size: 12px;
  color: #777;
}
</style>
</head>

<body>
<!-- NGRI Header -->
<?php include('ngriHeader.php');  ?>
<div class="container-fluid">
<nav class="navbar navbar-expand-sm bg-info navbar-dark">
  <!-- Brand -->
  <!--<a class="navbar-brand col-md-3 font-acme" href="#"><h5><i class="fas fa-globe"></i> Seismological Data Management Center (SDMC)</h5> </a> -->

  <!-- Links -->
  <ul class="navbar-nav">
    <li class="nav-item">
      <a class="nav-link" href="index.php"><i class="fas fa-home"></i> Home</a>
    </li>
    
 </ul>
</nav>
</div>
   <div class="container" style="min-height:70vh;">

    <div class="row">
      <div class="col-sm-9 col-md-7 col-lg-5 mx-auto">
        <div class="card card-signin my-5">
          <div class="card-body">
           <div id="erromsg"></div>
                
            <h5 class="card-title text-center">Sign In</h5>
            <form class="form-signin"  method="POST">
              <div class="form-label-group">
                <input type="text" id="username" name="username" class="form-control" placeholder="User Name" required>
  		
              	</div>

              	<div class="form-label-group">
                <input type="password" id="Password" name="Password" class="form-control" placeholder="Password" required>
               
              	</div>

             	 <button class="btn btn-lg btn-primary btn-block text-uppercase" type="submit" name="submit">Sign in</button>
		<br>
                <div class="hint-text">New Member? <a href="/thermodb/signup.php">Register here</a></div>  
      </form>
</div>
</div>
</div>
</div>
</div>
<div style="height:50px;"></div>

<div class="container-fluid">
<?php include('footer.php'); ?>
</div>
</body>
</html>



<?php

$servername = "localhost";
$username = "harini";
$password = "Seis@2019";
$dbname = "Thermodb";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
 

if(isset($_POST['submit'])) {
    
$username=$_POST['username'];
$Password=md5($_POST['Password']);
$message="";
if(count($_POST)>0) {
 $result = mysqli_query($conn,"SELECT * FROM users_tbl WHERE User_Name='$username' and Password='$Password'");

$row  = mysqli_fetch_array($result);
$_SESSION["User_Name"] = $row['User_Name'];
$_SESSION["Password"] = $row['Password'];
$_SESSION["Is_Active"] = $row['Is_Active'];
$_SESSION["Is_Admin"] = $row['Is_Admin'];
$Is_Active=$row['Is_Active'];
$Is_Admin=$row['Is_Admin'];
$_SESSION["timestamp"]=time();

// Check user exist and he is active

if($_SESSION["User_Name"] && $Is_Active=="TRUE" )
  {

   $_SESSION["login_time"] = time();

   if(isset($_GET['pg']))
      $page=$_GET['pg'];
   else
      $page=1;
   
   
    switch($page)
      {
      case 0:
           if ( $Is_Admin=="TRUE" )
           {
           $url1="Admin.php";
           }
           else
           {
//            echo 'Ok';
//          echo '<script language="javascript">$("#erromsg").html("<p class=\\"text-danger\\">You don't have permission to access this page!</p>");</script>';
           }
           break;
      case 1:
           $url1="viewDB.php";
           break;
      case 2:
           $url1="viewheatflow.php";
           break;
       } // End of Case
   
 
echo '<script>window.location.href = "'.$url1.'";</script>';

  }  
else
  {
 echo '<script language="javascript">$("#erromsg").html("<p class=\\"text-danger\\">Username is Not Activated contact Admin</p>");</script>';
  }

// End of is active  ******

// ******** Don't EDIT below ------------------ 

 } // End of Count of $_POST

} // End of isset(submit)

?>
