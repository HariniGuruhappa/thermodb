<!-- Main Header -->
<?php
require('config/adm_config.php');
?>

<?php   include('mainHeader.php');  ?>

<body>

<!-- NGRI Header -->
<?php include('ngriHeader.php');  ?>
<head>
 <link rel="stylesheet" href="./leaflet/leaflet.css"/>
 <script src="./leaflet/leaflet.js" i></script>
  <script src="./leaflet/leaflet.shpfile.js" ></script>
  <script src="./leaflet/shp.js" ></script>
<script src="https://cdn.plot.ly/plotly-latest.min.js"></script>
</head>
<style>
 /* Set black background color, white text and some padding */

html,body{
    width:100%;
    height:100%;
    //background-color:#EEDFCC;
}

.left1 {
margin-top: 5%;
font-weight: bold;
margin-left:18%;
}
a{

margin-top: 8%;
}
</style>
</head>

<body>
<?php include('admMainLogoutBar.php');  ?>
<div class="row">
<div class="col-md-7"> </div>
<div class="col-md-4"><a class="btn btn-danger text-center" href="Admin.php" style="float:right;"> BACK TO SEARCH</a> </div>
</div>
<div class="container-fluid">
<div class="row">
  <div class = "col-lg-10">
   <div class="left1">  

   
     <form id="myform" class="form-horizontal" action="/thermodb/thermal_insertionform.php" method="POST" >
        <div class=" form-group row">
  	<label class="col-lg-2.5  col-form-label" for="B_Name">Borehole Name:</label>
     	<div  class="col-lg-5" >
        <input type="text" class="form-control" id="B_Name" placeholder="Enter Borehole_Name" name="B_Name" required="required">
      	</div>

</div>
<br>
   <div class="form-group row">

        <label class="col-lg-2 col-form-label" for="B_Latitude">Latitude:</label>
       <div class="col-md-4">
       <input type="text" class="form-control" id="B_Latitude" placeholder="Enter Latitude" name="B_Latitude" required="required">
       </div>

	<label class="col-lg-2 col-form-label" for="B_Longitude">Longitude:</label>
      	<div class="col-md-4">
        <input type="datetime" class="form-control" id="B_Longitude" placeholder="Enter Longitude" name="B_Longitude" required="required">
        </div>
  
      
</div>
<br>
	
     	<div class="form-group row">
	<label class="col-lg-2 col-form-label" for="B_heatflow">Heatflow:</label>
      	 <div class="col-lg-4">
        <input type="text" class="form-control" id="B_heatflow" placeholder="Enter heatflow" name="B_heatflow" required="required">
      	</div>	

       <label class="col-lg-2 col-form-label" for="basal_heatflow">Basal Heatflow:</label>
       <div class="col-lg-4">
       <input type="text" class="form-control" id="basal_heatflow" placeholder="Enter b_heatflow" name="basal_heatflow" required="required">
       </div>
</div>

<br>
	<div class="form-group row">
	<label class="col-lg-2 col-form-label" for="thermal_conductivity">Thermal Conductivity:</label>
      	 <div class="col-lg-4">
        <input type="text" class="form-control" id="thermal_conductivity" placeholder="Enter conductivity" name="thermal_conductivity" required="required">
      	</div>	

       <label class="col-lg-2 col-form-label" for="heat_production">Heat Production:</label>
       <div class="col-lg-4">
       <input type="text" class="form-control" id="heat_production" placeholder="Enter production" name="heat_production" required="required">
       </div>
</div>

<br>
	<div class="form-group row">
	<label class="col-lg-2 col-form-label" for="crustal_thickness">Crustal Thickness:</label>
      	 <div class="col-lg-4">
        <input type="text" class="form-control" id="crustal_thickness" placeholder="Enter thickness" name="crustal_thickness" required="required">
      	</div>	

       <label class="col-lg-2 col-form-label" for="surface_temperature">Surface Temperature:</label>
       <div class="col-lg-4">
       <input type="text" class="form-control" id="surface_temperature" placeholder="Enter temperature" name="surface_temperature" required="required">
       </div>
</div>

<br>
	<div class="form-group row">
	<label class="col-lg-2 col-form-label" for="c_o_v">Coeff. of Variability:</label>
      	 <div class="col-lg-4">
        <input type="text" class="form-control" id="c_o_v" placeholder="Enter variability" name="c_o_v" required="required">
      	</div>	

       <label class="col-lg-2 col-form-label" for="c_l_s">Corr. Length Scale:</label>
       <div class="col-lg-4">
       <input type="text" class="form-control" id="c_l_s" placeholder="Enter lengthscale" name="c_l_s" required="required">
       </div>
</div>

<br>
	<div class="form-group row">
	<label class="col-lg-2 col-form-label" for="characteristic_depth">Characteristic Depth:</label>
      	 <div class="col-lg-4">
        <input type="text" class="form-control" id="characteristic_depth" placeholder="Enter depth" name="characteristic_depth" required="required">
      	</div>	
<!-- <label class="col-lg-2 col-form-label" for="author">Author:</label>
      	 <div class="col-lg-4">
        <input type="text" class="form-control" id="author" placeholder="Enter author" name="author" required="required">
      	</div>	 -->
</div>

<br>
	<div class="form-group row">
	

<!--       <label class="col-lg-2 col-form-label" for="authordatetime">Author Datetime:</label>
     	<div class="col-lg-4">
       <input type="text" class="form-control" id="datetimepicker1" 
	 name="authordatetime" required="required" placeholder="Enter YYYY-MM-DD hh:mm:ss" data-date-format="YYYY-MM-DD hh:mm:ss"/> 
 	
    	</div> -->
</div>

<br>
<center>
<div class="form-group row"> 
<div class="col-lg-8">    
 <button type="submit" class="btn btn-primary mb-2" name="submit">submit</button>
</div>
</div>

</center>

</form>
</div>
 </div>
</div>    
<?php include('footer.php'); ?> s    
</div>

</body>
</html>
<?php

$servername = "localhost";
$username = "harini";
$password = "Seis@2019";
$dbname = "Thermodb";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
if(isset($_POST['submit']))
{

$Borehole_name = $_POST['B_Name'];
$Borehole_Lat = $_POST['B_Latitude'];
$Borehole_Long = $_POST['B_Longitude'];
$heatflow = $_POST['B_heatflow'];
$basal_heatflow = $_POST['basal_heatflow'];
$thermal_conductivity = $_POST['thermal_conductivity'];
$heat_production = $_POST['heat_production'];
$crustal_thickness = $_POST['crustal_thickness'];
$surface_temperature = $_POST['surface_temperature'];
$coeff_of_variability = $_POST['c_o_v'];
$corr_length_scale = $_POST['c_l_s'];
$characteristicdepth = $_POST['characteristic_depth'];
$author = $_SESSION["User_Name"];


#echo "heat production: $heat_production";


$sql = "INSERT INTO thermoinfo_tbl (Borehole_name, Borehole_Lat, Borehole_Long, heatflow,basal_heatflow, thermal_conductivity,heat_production,crustal_thickness, surface_temperature,coeff_of_variability,corr_length_scale,characteristicdepth,author,author_datetime ) VALUES (NULLIF('$Borehole_name',''),NULLIF('$Borehole_Lat',''),NULLIF('$Borehole_Long',''),NULLIF('$heatflow',''),NULLIF('$basal_heatflow',''),NULLIF('$thermal_conductivity',''),NULLIF('$heat_production',''),NULLIF('$crustal_thickness',''),NULLIF('$surface_temperature',''),NULLIF('$coeff_of_variability',''),NULLIF('$corr_length_scale',''),NULLIF('$characteristicdepth',''),NULLIF('$author',''),NOW())";


if ($conn->query($sql) ==TRUE) {
    echo '<script language="javascript">alert("Added Successfully");</script>';
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

#echo $sql;

$conn->close();
}
?> 








