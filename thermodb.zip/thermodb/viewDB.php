<!-- FileNAME : viewThermoPlot.php Developed by 
Dr. Pavan Kumar Vengala, Seismic Hazard studies Group CSIR-NGRI -->
<?php
session_start();
if (!$_SESSION["User_Name"])
{
 echo '<script>window.location.href = "Login.php?pg=1";</script>';
}

?>


<!-- Main Header -->
<?php   include('mainHeader.php');  ?>

<body>

<!-- NGRI Header -->
<?php include('ngriHeader.php');  ?>


<head>
 <link rel="stylesheet" href="./leaflet/leaflet.css"/>
 <script src="./leaflet/leaflet.js" i></script>
  <script src="./leaflet/leaflet.shpfile.js" ></script>
  <script src="./leaflet/shp.js" ></script>
<script src="https://cdn.plot.ly/plotly-latest.min.js"></script>
</head>


<!-- SEIS Header -->
<!--Main nav bar -->
<div class="container-fluid">

<?php include('usrMainLogoutBar.php'); ?>

<div style="height:5px;"></div>
</div>

<div class="container-fluid">

<?php
require('./config/config.php');

$sql = "SELECT Borehole_ID,Borehole_name,Borehole_Lat,Borehole_Long,heatflow,".
       "basal_heatflow,thermal_conductivity,heat_production,crustal_thickness,".
       "surface_temperature,coeff_of_variability,corr_length_scale,characteristicdepth  FROM  thermoinfo_tbl";
     
//echo $sql;

$result = $conn->query($sql);

$f=0;
echo '<script> var  planes = [';
if ($result->num_rows > 0) {
    // output data of each row

 while($row = $result->fetch_assoc()) {

  if (! empty($row["Borehole_Lat"]) && !empty($row["Borehole_Long"]))
    echo '["'.$row["Borehole_name"].'",'.$row["Borehole_Lat"].','.$row["Borehole_Long"].','.$row["Borehole_ID"].'],';

$f++;
    }
} 
echo '];';
 
echo '</script>';

?>

<div class="row">

<div class="col-lg-6">

<div id="map1" style="width: 100%; height: 800px"></div>

</div> <!-- End of Map -->

<div class="col-lg-6">

<div id="stnId">
<h4 class="font-acme" style="color:red;padding-top:20px;">Search Results for Thermal Data </h4>
</div>

<div id="stnInfo">

<p>Clik on the location to  get the thermal parameters!</p>

</div>

</div> <!-- End of table -->


</div>

<div class="row">
<div id="plotInfo"> </div>

</div>


</div> <!-- End of Container -->

<?php

if(isset($_GET['id']))
{
echo '<script  type="text/javascript">';
echo ' $( document ).ready(function() {';
echo '  circleClick('.$_GET['id'].',null);';
echo '}); </script>';
}

?>



<div style="height:50px;"></div>

<div class="container-fluid">
<?php include('footer.php'); ?>
</div>
<script src="Leaflet.SvgShapeMarkers-gh-pages/dist/leaflet-svg-shape-markers.min.js"></script>

<script>
function polystyle(feature) {
    return {
        fillColor: 'white',
        weight: 2,
        opacity: 1,
        color: 'red',  //Outline color
        fillOpacity: 0.7
    };
}


var mymap = L.map('map1', {
			center: [22, 82],
			zoom: 4.5
		});

var polyIndia = JSON.parse($.ajax({'url': "./India/polyIndia.json", 'async': false}).responseText); 

var poly = L.polygon(polyIndia, {
    color: 'black',
    fillColor: '#fff',
    fillOpacity: 0.1,
     weight: 1.5,
 }).addTo(mymap);
//var mgroup = L.featureGroup(markers);

//var L4 = L.layerGroup(markers);


	L.tileLayer('https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token=pk.eyJ1IjoibWFwYm94IiwiYSI6ImNpejY4NXVycTA2emYycXBndHRqcmZ3N3gifQ.rJcFIG214AriISLbB6B5aw', {
		maxZoom: 18,
		attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, ' +
			'<a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, ' +
			'Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
		id: 'mapbox.streets'
	}).addTo(mymap);


var LeafIcon = L.Icon.extend({
		options: {
			//shadowUrl: 'icons/triangle-red.png',
			iconSize:     [28, 25],
			//shadowSize:   [50, 64],
			iconAnchor:   [22, 94],
			//shadowAnchor: [4, 62],
			popupAnchor:  [-3, -76]
		}
	});


var greenIcon = new LeafIcon({iconUrl: 'icons/triangle-red.png'});


for (var i = 0; i < planes.length; i++) {
			
 var triangle = L.shapeMarker([planes[i][1],planes[i][2]], {
		fillColor: "red",
                fillOpacity: 0.9,
		color: "red",
		shape: "triangle",
		radius: 8
	}).bindPopup(planes[i][0])
  	  .on('click', circleClick.bind(null,planes[i][3] ))
          .addTo(mymap);


/*circle = L.circle([planes[i][1],planes[i][2]], {
          color: "red",
          fillColor: "#f03",
          fillOpacity: 0.5,
          radius: 200
      }).on('click', circleClick.bind(null,planes[i][0] )).addTo(mymap);  */

		}

/*---------------------------------------------------------- */

/*var shpfile = new L.Shapefile('India/IN.zip'); 
shpfile.addTo(mymap);*/


function circleClick(b,e)
{
//alert(b);

$('#plotInfo').html('');

 $.ajax({
    	method: "GET", url: "api/api.php?id="+b, 
  	}).done(function( data ) {
   	var result = $.parseJSON(data);
   	var string = '<table class=\"table table-hover table-bordered\">';
   	length = result.length;
	var stnName;
  $.each( result, function( key, value ) {
      stnName=value['Borehole_name'];
     string += "<tr><td>Location Name</td><td>"+value['Borehole_name']+ "</td></tr>";
     string += "<tr><td>Latitude (<sup>o</sup>N) </td><td> "+ value['Borehole_Lat']+"</td> </tr>";
     string += "<tr><td>Longitude (<sup>o</sup>E) </td><td> "+ value['Borehole_Long']+"</td> </tr>";
     string += "<tr><td>Heat Flow (mW/m<sup>2</sup>) </td><td> "+ value['heatflow']+"</td> </tr>";  
     string += "<tr><td>Basal Heat Flow (mW/m<sup>2</sup>) </td><td> "+value['basal_heatflow']+"</td> </tr>";
     string += "<tr><td>Thermal Conductivity (W/m<sup>2</sup>) </td><td> "+ value['thermal_conductivity']+"</td> </tr>";
     string += "<tr><td>Heat Production (&#956 W/m<sup>3</sup>)</td><td> "+ value['heat_production']+"</td> </tr>";  
     string += "<tr><td>Crustal Thickness (Km) </td><td> "+value['crustal_thickness']+"</td> </tr>";   
     string += "<tr><td>Characteristic Depth (Km) </td><td> "+value['characteristicdepth']+"</td> </tr>";   
      
   
    });
    
    string += '</table>';

    string += '<a class="btn btn-sm btn-warning" href="viewThermoPlot.php?id='+b+'">Plot for Temperature Profile</a>';

    $('#stnId h4').html("Search Results for Thermal Data: "+stnName+"");

    $("#stnInfo").html(string);

      });


 $.ajax({
    	method: "GET", url: "api/mapapi.php?id="+b, 
  	}).done(function( data ) {
      
       });


}

</script>


</body>
</html>
<!-- FileNAME : viewThermoPlot.php Developed by 
(c) Dr. Pavan Kumar Vengala, Seismic Hazard studies Group, CSIR-NGRI -->
