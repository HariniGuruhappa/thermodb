
%crustal thickness
t1 = 45;
N =350;
%basel heat flow
qb1= 18;
qb=qb1*10^-3;
%correlation length scale
rr1=70;
rr=1/(rr1*10*10*10);
r0 = rr;
%coffiencient of variability
ck1=0.2*0.2;
%surface temperature
t0 = 32;
AL = N*(10^3);
%thermal conductivity
ak=2.6;
%characteristic depth
D =11.5;
%heat production
A1=1.59;
A0= A1*10^-6;
ck = ck1/(ak*ak);
r1 = r0 * D-1;
q1 = qb - (A0*D*exp(-AL/D));
c= (A0* D* D)/ak;
r2= r0 + (1/D);
r3= r0 - (1/D);
r4 = r0 *D + 1;
con1 = ck*A0*A0*r1*r1;
con2 = ck*A0*r0*q1*r1;
con3=con2;
con4 = ck* r0*r0*q1*q1;

TUB0 = zeros(1,N+1);
TLB0 = zeros(1,N+1);
SD0 = zeros(1,N+1);
%---------- CALCULATING T(Z) FOR 0<=Z<=hc  i.e Tz0-----------------
     z=[0:1000:N*1000];
    Tz0 = zeros(1,N+1);
    T1= t0 + (qb*z)/ak;
      T2= c* (1-((z/D)*exp(-AL/D))- exp(-z/D));
     Tz0= T1 + T2;
%----------- CALCULATING SD FOR 0<=Z<=hc --------------------
%------ CALCULATING TERM1 -----------

cf1 = 2*(z.*z) - 2*z*D - D*D*exp(-2*z/D) + D*D;
cf2 = (-z*r2 - exp(-z*r2) + 1) / (r2*r2);
cf3 = -cf1 + 2*z.*z ;
f11 = r1*cf1;
f12 = 4*(z*r3+1).*cf2;
f13 = cf3;
f1 =(f11+f12+f13)/(4*r3*r3);

cs1=cf1;
cs2= -z*r3.*exp(-z*r2) + exp(-2*z/D) - exp(-z*r2);
cs3 = -f13;
s11= r4*cs1;
s12= 4*cs2/(r3*r3);
s13=cs3;
s1= (s11+s12+s13)/(4*r2*r2);
Term1 = con1*(f1+ s1);
%------ CALCULATING TERM2 -----------
  cs21= z.*z*D - 2*z*D*D - 2*(D^3)*exp(-z/D) + 2*(D^3);
  f21 = 2*r0*cs21;
  cs22 = z*r2 + exp(-(z*r2)) -1;
  f22 = -( (1 + r0*z) / (r2^2)) .* cs22;
  cs23 = -z*r3 + exp(z*r3) - 1;
  f23 = (exp(-r0*z)/(r3*r3)).*cs23;
  Term2 = con2*(f21+f22+f23)/(r0^2);
%---------CALCULATING TERM3-------------
  cf31 = z.*z*D - 2*z*D*D - 2*(D^3)*exp(-z/D) + 2*(D^3);
  cf32= (r0*z + exp(-r0*z) - 1)/(r0*r0);
  cf33 = z*D + D*D*(exp(-z/D) -1);
  f31 = r3 *cf31;
  f32 = -(z*r3 + 1).* cf32;
  f33= cf33;
  f3 = (f31+f32+f33)/(r3^2);
  cs31=cf31;
  cs32 = (-r0*z + exp(r0*z) - 1)/(r0^2);
  cs33 = cf33;
  s31 = r2*cf31;
  s32= exp(-z*r2).*cs32;
  s33= -cs33;%cs32
  s3= (s31+s32+s33)/(r2^2);
  Term3 = con3*(f3+s3);
  %---------CALCULATING TERM4-------------
  f41 = 2*r0*(z.*z.*z)/3;
  f42 = -((r0*z + 1) .* cf32);
  f43 = exp(-r0*z).* cs32;
  Term4 = con4*(f41+f42+f43)/(r0^2);
  %---------CALCULATING SD0-------------
  V0= Term1 + Term2 + Term3 + Term4;
  SD0 = sqrt(V0);
  %---------CALCULATING TLB & TUB-------------
  TUB0 = Tz0 + SD0;
  TLB0 = Tz0 - SD0;
%-----------FINAL VALUES ----------     
 %TF = zeros(1,N1+1);
 %TUBF = zeros(1,N1+1);
 %TLBF = zeros(1,N1+1);

for i = 1:N+1
    TF(i) = Tz0(i);                                               %round(Tz0(i),2);
    TUBF(i) = TUB0(i);
    TLBF(i) = TLB0(i);
    SDF(i)= SD0(i);                                                                       %round(SD0(i),2);
end 
 ZF = [1:N+1];
handles.m=1;
while  ZF(handles.m)<=N                              
   handles.TUBFG(handles.m)=TUBF(handles.m);
   handles.TLBFG(handles.m)=TLBF(handles.m);
   handles.TFG(handles.m)=TF(handles.m);
   handles.ZFG(handles.m)=ZF(handles.m);
   handles.SDFG(handles.m)=SDF(handles.m);
  handles.m=handles.m+1;
end
   TplusSD=handles.TUBFG(:);
   TminusSD=handles.TLBFG(:);
   T=handles.TFG(:);
   Z=handles.ZFG(:);
a=[25 50 100 150 200 250 300 350]
b=[1105 1120 1185 1280 1375 1470 1565 1660] 
fileID=fopen('Tempprofile_Data.txt','w');
fprintf(fileID,'%8s %16s %14s %14s \r\n','T+SD','T-SD','T','Z')
for jp=1:length(Z)
fprintf(fileID,'%6.5f \t %6.5f \t %6.5f \t %f \r\n',TplusSD(jp),TminusSD(jp),T(jp),Z(jp));
end
fclose(fileID);




