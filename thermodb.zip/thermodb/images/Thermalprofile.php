<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta name="viewport" content="width=device-width, initial-scale=1,maximum-scale=1.0">
  <link rel="stylesheet" href="./css/bootstrap.min.css">
  <script src="./jquery.min.js"></script>
  <script src="./js/bootstrap.min.js"></script>
<style>
 /* Set black background color, white text and some padding */

body{
    width:100%;
    height:100%;
    background-color:#EEDFCC;
}
.header-img {
  width: 100%;
  height: 50px;
  margin-top: 10px;
  background: url('./image1.png');
  background-size: cover;
}
.eart {
  float: left;
  margin-left: 20px;
  font-family: MV Boli;
  color:gold;
}
.text-header {
font-family: MV Boli;
  color:gold;
font-size: 30px;
}
</style>
</head>

<body>
<div class="header-img">
<div class="eart">
 <img src='./earth.png' height=50px>  
</div>
<div class="text-header">
THERMAL STRUCTURE ACROSS INDIA
</div>
</div>
</body>
</html>
