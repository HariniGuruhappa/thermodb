
<?php
// Start the session
session_start();
?>
<?php   include('mainHeader.php');  ?>

<script src="js/countrypicker.js"></script>

 <style type="text/css">
html,body{
    width:100%;
    height:100%;
    //background-color:#EEDFCC;
}
.register{
    margin-top: 1%;
    padding: 2%;
}
.register-left{
    text-align: center;
    color: #fff;
    margin-top: 7%;
}
.register-left input{
    border: none;
    border-radius: 1.5rem;
    padding: 2%;
    width: 50%;
    background: #f8f9fa;
    font-weight: bold;
    color: #383d41;
    margin-top: 30%;
    margin-bottom: 3%;
    cursor: pointer;
}
.register-right{
    background: #f8f9fa;
    border-top-left-radius: 10% 50%;
    border-bottom-left-radius: 10% 50%;
   margin-left: 5%;
  
}
.register-left p{
    font-weight: lighter;
    padding: 10%;
    margin-top: -9%;
}
.register .register-form{
    padding: 10%;
    margin-top: 10%;
}
.btnRegister{
    float: right;
    margin-top: 10%;
    border: none;
    border-radius: 1.5rem;
    padding: 2%;
    background: #0062cc;
    color: #fff;
    font-weight: 600;
    width: 50%;
    cursor: pointer;
}
.register .nav-tabs{
    margin-top: 3%;
    border: none;
    background: #0062cc;
    border-radius: 1.5rem;
    width: 28%;
    float: right;
}
.register .nav-tabs .nav-link{
    padding: 2%;
    height: 34px;
    font-weight: 600;
    color: #fff;
    border-top-right-radius: 1.5rem;
    border-bottom-right-radius: 1.5rem;
}
.register .nav-tabs .nav-link:hover{
    border: none;
}
.register .nav-tabs .nav-link.active{
    width: 100px;
    color: #0062cc;
    border: 2px solid #0062cc;
    border-top-left-radius: 1.5rem;
    border-bottom-left-radius: 1.5rem;
}
.register-heading{
    text-align: center;
    margin-top: 8%;
    margin-bottom: -15%;
    color: #0062cc;
}
.default
{
content:"Please select a country";
}


</style>
</head>
<body>

<?php include('ngriHeader.php');  ?>
<?php include('mainlogoutbar.php');  ?>
<div class="row">

<div class="col-lg-7"> </div>
<div class="col-lg-4"><a class="btn btn-danger text-center" href="Admin.php" style="float:right;"> BACK TO SEARCH</a> </div>
</div>
<?php

$servername = "localhost";
$username = "harini";
$password = "Seis@2019";
$dbname = "Thermodb";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$id=$_GET["ID"];
if(!isset($id))
{
$id=1;
}



// sql to create table

$sql = "SELECT First_Name,Last_Name,User_Name,Email_ID,Designation,Institute,Is_Admin,Is_Active,sendmail FROM users_tbl WHERE User_ID=$id";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
      
                
		$Firstname=$row['First_Name'];
		$Lastname=$row['Last_Name'];
		$Username=$row['User_Name'];
		$Email=$row['Email_ID'];
		$Designation=$row['Designation'];
		$Institute=$row['Institute'];
		$Is_Admin=$row['Is_Admin'];
		$Is_Active=$row['Is_Active'];
		$sendmail=$row['sendmail'];
	
 }
} else {
    echo "0 results";
}



?>

<div class="container register">
<div class="signup-form">
<form action="/thermodb/updateuser.php?ID=<?php echo $id?>" method="post" name="form1">    
<div class="row">

         <div class="col-md-10 register-right">                            
         <div class="tab-content" id="myTabContent">
         <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
         <h3 class="register-heading">User Registration Details</h3>
         <div class="row register-form">


		
		           
		<div class="col-md-6">
		<div class="form-group">
		FIRSTNAME:<input type="text" class="form-control" name="FirstName" value='<?php echo $Firstname; ?>'>
                </div>
		   
		<div class="form-group">
                USERNAME:<input type="text" class="form-control" name="UserName" value='<?php echo $Username; ?>'>
                </div>	
		
		<div class="form-group">
                DESIGNATION:<input type="text" class="form-control" name="Designation" value='<?php echo $Designation; ?>'>
                </div>
		<div class="form-group">
                IS_ADMIN:<input type="text" class="form-control" name="Is_Admin" value='<?php echo $Is_Admin; ?>'>
                </div>	
		<div class="form-group">
                SENDMAIL:<input type="text" class="form-control" name="sendmail" value='<?php echo $sendmail; ?>'>
                </div>	
		
                
	</div>
                                        
		<div class="col-md-6">
		<div class="form-group">
                LASTNAME:<input type="text" class="form-control" name="LastName" value='<?php echo $Lastname; ?>'>
                </div>
		
                <div class="form-group">
                EMAIL<input type="email" class="form-control" name="Email"  value='<?php echo $Email; ?>'>
                </div>                        
                <div class="form-group">
                INSTITUTE:<input type="text" class="form-control" name="Institute" value='<?php echo $Institute; ?>'>
                </div>	
		<div class="form-group">
        	IS_ACTIVE:<input type="text" class="form-control" name="Is_Active" value='<?php echo $Is_Active; ?>'>
        	</div>			
			
		
	</div>
		<button type="submit" class="btn btn-primary btn center" name="update" onclick="return Validate()" >Update</button>
		</div>
             	</div>
                </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
		
<?php include('footer.php'); ?>   
</body>

</html>



