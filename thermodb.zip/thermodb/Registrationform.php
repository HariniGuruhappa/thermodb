<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="./css/bootstrap.min.css">
  <script src="./jquery.min.js"></script>
  <script src="./js/bootstrap.min.js"></script>

<style>
/* Set black background color, white text and some padding */
     .footer {
      position: absolute;
 	 bottom: 0;
	width: 100%;
	background-color: #425766;
      	color: white;
      	text-align: center;
    } 

.body{
    width:100%;
    height:100%;
}
.form-control{
		height: 35px;
		background: #f2f2f2;
		box-shadow: none !important;
		border: none;
	}
.form-control:focus{
		background: #e2e2e2;
	}
.form-control, .btn{        
        border-radius: 3px;
    }
.signup-form{
		width: 490px;
		margin: 30px auto;
		margin-top: 10%;
	}
.signup-form form{
		color: #999;
		border-radius: 3px;
    	margin-bottom: 15px;
        background: #fff;
        box-shadow:  0px 0px 2px 2px rgba(0, 0, 0, 0.3);
        padding: 30px;
    }
.signup-form h2 {
		color: #333;
		font-weight: bold;
        margin-top: 0;
    }
 .signup-form hr {
        margin: 0 -30px 20px;
    }    
	.signup-form .form-group{
		margin-bottom: 20px;
	}
	.signup-form input[type="checkbox"]{
		margin-top: 3px;
	}
	.signup-form .row div:first-child{
		padding-right: 10px;
	}
	.signup-form .row div:last-child{
		padding-left: 10px;
	}
    .signup-form .btn{        
        font-size: 16px;
        font-weight: bold;
		background: #3598dc;
		border: none;
		min-width: 140px;
    }
	.signup-form .btn:hover, .signup-form .btn:focus{
		background: #2389cd !important;
        outline: none;
	}
    .signup-form a{
		color: #fff;
		text-decoration: underline;
	}
	.signup-form a:hover{
		text-decoration: none;
	}
	.signup-form form a{
		color: #3598dc;
		text-decoration: none;
	}	
	.signup-form form a:hover{
		text-decoration: underline;
	}
    .signup-form .hint-text {
		padding-bottom: 15px;
		text-align: center;
    }
h4 {
   color:	#1E90FF	;
}
p
{
color:	#A52A2A;
}
 
</style>
</head>
<body>

<div class="signup-form">
    <form action="/thermodb/Registrationform.php" method="post" name="form1">
		<h4>Registration Form</h4>
		<p>Please fill in this form to create an account!</p>
		<hr>
       	<div class="form-group">
        <input type="text" class="form-control" name="User_Title" placeholder="User_Title" required="required" list="Title">
	<datalist id="Title">
  	<option>Mr.</option>
  	<option>Ms.</option>
  	<option>Dr.</option>
  	</datalist>

        </div>
        <div class="form-group">
	<div class="row">
	<div class="col-xs-6"><input type="text" class="form-control" name="Firstname" placeholder="Firstname" required="required"></div>
	<div class="col-xs-6"><input type="text" class="form-control" name="Lastname"  placeholder="Lastname" required="required"></div>
	</div>        	
        </div>
        <div class="form-group">
     	<input type="email" class="form-control" name="Email" placeholder="Email" required="required">
        </div>
	<div class="form-group">
        <input type="password" class="form-control" name="Password" placeholder="Password" title="Password must contain at least 6 characters, including UPPER/lowercase and numbers." 	required pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}" required="required" id="Password">

        </div>
	<div class="form-group">
        <input type="password" class="form-control" name="Confirm_Password" 
	placeholder="Confirm Password" required="required" id="Confirm_Password">
        </div>
	<div class="form-group">
        <input type="text" class="form-control" name="Designation" placeholder="Designation" required="required">
        </div>
	<div class="form-group">
        <input type="text" class="form-control" name="Institute" placeholder="Institute" required="required">
        </div>
	<div class="form-group">
        <input type="text" class="form-control" name="Addressline1" placeholder="Address Line 1">
        </div>
	<div class="form-group">
        <input type="text" class="form-control" name="Addressline2" placeholder="Address Line 2">
        </div>
	<div class="form-group">
        <input type="text" class="form-control" name="City" placeholder="City/Town/Village">
        </div>
	<div class="form-group">
        <input type="text" class="form-control" name="State" placeholder="State">
        </div>
	<div class="form-group">
        <input type="text" class="form-control" name="Zip" placeholder="Zip/Postal Code">
        </div>
	<div class="form-group">
        <input type="text" class="form-control" name="Country" placeholder="Country">
        </div>

	<div class="form-group">
         <input type="text" class="form-control" name="Phone_Number" placeholder="Phone_Number" title="atleast 10 numbers "required="required">
        </div>  
       
        <div class="form-group">
	<label class="checkbox-inline"><input type="checkbox" required="required"> I accept the <a href="#">Terms of Use</a> &amp; <a href="#">Privacy Policy</a></label>
	</div>
	<div class="form-group">
        <button type="submit" class="btn btn-primary btn-lg" name="Register" onclick="return Validate()" >Register</button>
        </div>
	<div class="hint-text">Already have an account? <a href="/seisdb/Loginform.php">Login here</a></div>
</form>
</div>
 <script type="text/javascript">
    function Validate() {
        var Password = document.getElementById("Password").value;
        var Confirm_Password = document.getElementById("Confirm_Password").value;
        if (Password != Confirm_Password) {
            alert("Password and Confirm Password do not match.");
            return false;
        }
        return true;
    }
</script>

</body>
</html>
<?php
$servername = "localhost";
$username = "harini";
$password = "NGRI@123";
$dbname = "Thermodb";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
if(isset($_POST['Register']))
{
$User_Title = $_POST['User_Title'];
$Firstname = $_POST['Firstname'];
$Lastname = $_POST['Lastname'];
$Email = $_POST['Email'];
$Password = md5($_POST['Password']);
$Confirm_Password = md5($_POST['Confirm_Password']);
$Designation = $_POST['Designation'];
$Institute = $_POST['Institute'];
$Reference = $_POST['Reference'];
$Housenumber = $_POST['Housenumber'];
$Addressline1 = $_POST['Addressline1'];
$Addressline2 = $_POST['Addressline2'];
$State = $_POST['State'];
$Zip = $_POST['Zip'];
$Country = $_POST['Country'];
$Registration_Date = $_POST['Registration_Date'];
$Phone_Number = $_POST['Phone_Number'];



$sql = "INSERT INTO Userlogininfo_Pending_tbl ( User_Title, Firstname, Lastname, Email, Password,Confirm_Password,Designation, Institute, Reference, Housenumber, Addressline1, Addressline2, State, Zip, Country, Registration_Date, Phone_Number ) VALUES ('$User_Title','$Firstname','$Lastname','$Email','$Password','$Confirm_Password','$Designation','$Institute','$Reference ','$Housenumber','$Addressline1','$Addressline2','$State','$Zip','$Country','$Registration_Date','$Phone_Number')";

if ($conn->query($sql) ==TRUE) {
    echo '<script language="javascript">alert("Pending For Admin Approval");</script>';
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
}
?>


