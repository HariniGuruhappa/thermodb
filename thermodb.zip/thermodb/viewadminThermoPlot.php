<!-- Main Header -->
<?php
// Start the session
session_start();
?>
<?php   include('mainHeader.php');  ?>

<body>

<!-- NGRI Header -->
<?php include('ngriHeader.php');  ?>

<head>
 <link rel="stylesheet" href="./leaflet/leaflet.css"/>
 <script src="./leaflet/leaflet.js" i></script>
<script src="https://cdn.plot.ly/plotly-latest.min.js"></script>
</head>


<!-- SEIS Header -->
<!--Main nav bar -->
<div class="container-fluid">
<nav class="navbar navbar-expand-sm bg-info navbar-dark">
  <!-- Brand -->
  <!--<a class="navbar-brand col-md-3 font-acme" href="#"><h5><i class="fas fa-globe"></i> Seismological Data Management Center (SDMC)</h5> </a> -->

  <!-- Links -->
  <ul class="navbar-nav">
    <li class="nav-item">
      <a class="nav-link" href="index.php"><i class="fas fa-home"></i> Home</a>
    </li>
    
    <li class="nav-item">
      <a class="nav-link" href="Logout.php"><i class="fas fa-database"></i> Logout</a>
    </li>

<!--
    <li class="nav-item">
      <a class="nav-link" href="contact.php"><i class="fas fa-handshake"></i> Contact us</a>
    </li>
 
   
    <li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
        <i class="fas fa-search-location"></i> Search Catalog
      </a>
      <div class="dropdown-menu">
        <a class="dropdown-item" href="#"><span><i class="fas fa-globe"></i></span> Network Catalog </a>
        <a class="dropdown-item" href="stnCatalog.php"><span><i class="fas fa-globe"></i></span> Station Catalog</a>
        <a class="dropdown-item" href="#"><span><i class="fas fa-globe"></i></span> Earthquake Catalog</a>
      </div>
    </li>  -->
       
  </ul>
</nav>

<div style="height:20px;"></div>
</div>

<div class="container-fluid">

<?php
require('./config/config.php');
$gid=$_GET['id'];
echo '<script  type="text/javascript">var gid='.$gid.'; </script>';
?>

<div class="row">

<div class="col-lg-8"> </div>

<div class="col-lg-4"><a class="btn btn-danger text-center" href="viewadminDB.php?id=<?php echo $gid; ?>" style="float:right;"> BACK TO SEARCH</a> </div>

</div>



<div class="row">

<div class="col-lg-6">

<hr>
<div id="stnHdr">

<h4 class="font-acme text-center">Search Results For </h4>

</div>

<hr>
<div id="stnInfo">

<script  type="text/javascript"> 
 $( document ).ready(function() {
  circleClick(gid);
});

 </script>

 </div>


</div> <!-- End of Map -->

<div class="col-lg-6">

<div id="plotInfo"> 

<script  type="text/javascript">
 $( document ).ready(function() {
   showPlot(gid);
}); </script>

</div>

</div> <!-- End of table -->

</div>

</div> <!-- End of Container -->

<div style="height:50px;"></div>

<div class="container-fluid">
<?php include('footer.php'); ?>
</div>
<script src="Leaflet.SvgShapeMarkers-gh-pages/dist/leaflet-svg-shape-markers.min.js"></script>

<script  type="text/javascript">


function circleClick(b)
{
//alert(b);

$('#plotInfo').html('');

 $.ajax({
    	method: "GET", url: "api/api.php?id="+b, 
  	}).done(function( data ) {
   	var result = $.parseJSON(data);
   	var string = '<table class=\"table table-hover table-bordered\">';
   	length = result.length;
	var stnName;
  $.each( result, function( key, value ) {

     stnName=value['Borehole_name'];

     string += "<tr><td>Location Name</td><td>"+value['Borehole_name']+ "</td></tr>";
     string += "<tr><td>Latitude (<sup>o</sup>N) </td><td> "+ value['Borehole_Lat']+"</td> </tr>";
     string += "<tr><td>Longitude (<sup>o</sup>E) </td><td> "+ value['Borehole_Long']+"</td> </tr>";
     string += "<tr><td>Heat Flow (mW/m<sup>2</sup>) </td><td> "+ value['heatflow']+"</td> </tr>";  
     string += "<tr><td>Basal Heat Flow (mW/m<sup>2</sup>) </td><td> "+value['basal_heatflow']+"</td> </tr>";
     string += "<tr><td>Thermal Conductivity (W/m<sup>2</sup>) </td><td> "+ value['thermal_conductivity']+"</td> </tr>";
     string += "<tr><td>Heat Production (&#956 W/m<sup>3</sup>)</td><td> "+ value['heat_production']+"</td> </tr>";  
     string += "<tr><td>Crustal Thickness (Km) </td><td> "+value['crustal_thickness']+"</td> </tr>";   
     string += "<tr><td>Characteristic Depth (Km) </td><td> "+value['characteristicdepth']+"</td> </tr>";   
      
   
    });
    
    string += '</table>';
      

	$('#stnHdr h4').html("<strong>Search Results <br> "+stnName+"</strong>");
      //$("#stnHdr h2").html("Search results for "+stnName+" );
    $("#stnInfo").html(string);
   
      });

// Running octave code in background

 $.ajax({
    	method: "GET", url: "api/mapapi.php?id="+b, 
  	}).done(function( data ) {
      
       });


}


function showPlot(id)
{

//alert(id);
  
fileName='maps/Tempprofile_Data'+id+'.txt';

$(document).ready(function() {
    $.ajax({
        type: "GET",
        url: fileName,
        dataType: "text",
        success: function(data) {processData(data);}
     });
});


}

function processData(data)
{

var lines = data.split(/\r\n|\n/);
        //Set up the data arrays
        var depth = [];
        var temp = [];
        var tsdplus = [];
        var tsdminus = [];

 var headings = lines[0].split(','); // Splice up the first row to get the headings

       for (var j=1; j<lines.length; j++) {

  /*      for (var j=lines.length-1; j>=1; j--) {*/

        var values = lines[j].split(','); // Split up the comma seperated values
           // We read the key,1st, 2nd and 3rd rows 
           tsdplus.push(values[0]); // Read in as string
           // Recommended to read in as float, since we'll be doing some operations on this later.
           tsdminus.push(parseFloat(values[1])); 
           temp.push(parseFloat(values[2]));
           depth.push(parseFloat(values[3]));
        }


//alert(depth);

var trace1 = {
  x: temp,
  y: depth,
  xaxis: 'Depth (Km)',
  yaxis: 'Temperature ()',
  name: 'T',
 type: 'scatter',
};

var trace2 = {
  x: tsdplus,
  y: depth,
  name: 'T+SD',
  type: 'scatter',
   line: {
    dash: 'dot',
    width: 4
  }
};

var trace3 = {
  x: tsdminus,
  y: depth,
  name: 'T-SD',
 type: 'scatter',
   line: {
    dash: 'dot',
    width: 4
  }
};


var mantle = {
 x:[1105,1120,1185,1280,1375,1470,1565,1660],
 y:[25,50,100,150,200,250,300,350],
 name:'Mantle Solidus',
  type: 'scatter'
}


var data = [trace1,trace2,trace3,mantle];

var tempMiddle = Math.floor(temp.length / 2);
var tempValue = temp[tempMiddle]+150;
var tempDepth = depth[tempMiddle];

var tsdPlusMiddle = Math.floor(tsdplus.length / 2);
var tsdPlusValue = tsdplus[tsdPlusMiddle]+150;
var tsdPlusDepth = depth[tsdPlusMiddle];

var tsdMinusMiddle = Math.floor(tsdminus.length / 2);
var tsdMinusValue = tsdplus[tsdMinusMiddle];
var tsdMinusDepth = depth[tsdMinusMiddle];

/*
var layout = {
    title: {
    text:"",
   
    font: {
      family: 'Courier New, monospace',
      size: 24
    },xref: 'paper',
    x: 0.05,},
    height: 600,
    width: 650,
    xaxis: {
      zeroline: true,
     mirror:'ticks',
      dtick: 500,
     side: 'top',
    range: [0,3500],
   autorange:true,
  
     mirror: 'ticks',
    title: {
      text: 'Temperature (<sup>o</sup>C)',
      font: {
        family: 'Courier New, monospace',
        size: 18,
        color: '#7f7f7f'
      }
    },
  },
 yaxis: {
    mirror: 'ticks',
    autorange: 'reversed',
    title: {
      text: 'Depth (z) (Km)',
     
      font: {
        family: 'Courier New, monospace',
        size: 18,
        color: '#7f7f7f'
      }
    },
  },

 annotations: [
    {
      x: tempValue,
      y: tempDepth,
      xref: 'x',
      yref: 'y',
      text: 'T',
      textangle: '35',
      showarrow: false
     },
   {  
      x: tsdPlusValue,
      y: tsdPlusDepth,
      xref: 'x',
      yref: 'y',
      text: 'T+SD',
      textangle: '30',
      showarrow: false
      
      },
    {  
      x: tsdMinusValue-900,
      y: 176,
      xref: 'x',
      yref: 'y',
      text: 'T-SD',
      textangle: '55',
      showarrow: false
      }

  ],
}; */

var layout = {
    title: {
    text:"",
   
    font: {
      family: 'Courier New, monospace',
      size: 24
    },xref: 'paper',
    x: 0.05,},
    height: 600,
    width: 650,


  xaxis: {
     dtick: 500,
     side: 'top',
    
   autorange:true,
    showgrid: true,
  
    
    
    gridcolor: '#bdbdbd',
    gridwidth: 0.2,
   
    
     title: {
      text: 'Temperature (<sup>o</sup>C)',
      font: {
        family: 'Courier New, monospace',
        size: 18,
        color: '#7f7f7f'
      }
    },
     
  },
  yaxis: {
    dtick: 50,
     side: 'left',
    range: [0,350],
    autorange: 'reversed',
    showgrid: true,
   
   
    gridcolor: '#bdbdbd',
    gridwidth: 0.2,
    zerolinecolor: '#969696',
    zerolinewidth: 0,
    linecolor: '#636363',
    linewidth: 2,
     title: {
      text: 'Depth (z) (Km)',
     
      font: {
        family: 'Courier New, monospace',
        size: 18,
        color: '#7f7f7f'
      }
    },

  }
};



Plotly.newPlot('plotInfo', data, layout);





}


</script>


</body>
</html>

