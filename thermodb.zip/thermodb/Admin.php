<!-- Main Header -->
<?php
require('config/adm_config.php');
?>
<?php   include('mainHeader.php');  ?>



<!-- NGRI Header -->
<?php include('ngriHeader.php');  ?>
<head>
 <link rel="stylesheet" href="./leaflet/leaflet.css"/>
 <script src="./leaflet/leaflet.js" i></script>
  <script src="./leaflet/leaflet.shpfile.js" ></script>
  <script src="./leaflet/shp.js" ></script>
<script src="https://cdn.plot.ly/plotly-latest.min.js"></script>
<style>
 
html,body{
    width:100%;
    height:100%;
}
a
{
font-size:22px;
}
</style>
</head>
<body>

<?php include('admMainLogoutBar.php');  ?>
<div style="height:0px;"></div>
</div>

<div class="container-fluid">
    <div class="row">
        <aside class="col-md-4.3 px-4 fixed" id="left">

            <div class="list-group w-140">
                <a href="heatflow_insertionform.php" class="list-group-item">INSERT HEATFLOW DATA</a>
                <a href="thermal_insertionform.php" class="list-group-item">INSERT THERMAL DATA</a>
                <a href="viewadminDB.php" class="list-group-item">VIEW TEMPERATURE PROFILES</a>
  		<a href="viewadminheatflow.php" class="list-group-item">VIEW HEATFLOW DATA</a>
                <a href="usersform.php" class="list-group-item">VIEW USERS AND APPROVE</a>
               
            </div>

        </aside>

</div>
</div>
<?php include('footer.php'); ?>
</div>

</body>
</html>
