
<?php
// Start the session
session_start();
?>
<?php   include('mainHeader.php');  ?>

<script src="js/countrypicker.js"></script>

 <style type="text/css">
.register{
    margin-top: 5%;
    padding: 2%;
}
.register-left{
    text-align: center;
    color: #fff;
    margin-top: 7%;
}
.register-left input{
    border: none;
    border-radius: 1.5rem;
    padding: 2%;
    width: 50%;
    background: #f8f9fa;
    font-weight: bold;
    color: #383d41;
    margin-top: 30%;
    margin-bottom: 3%;
    cursor: pointer;
}
.register-right{
    background: #f8f9fa;
    border-top-left-radius: 10% 50%;
    border-bottom-left-radius: 10% 50%;
}
.register-left p{
    font-weight: lighter;
    padding: 10%;
    margin-top: -9%;
}
.register .register-form{
    padding: 10%;
    margin-top: 10%;
}
.btnRegister{
    float: right;
    margin-top: 10%;
    border: none;
    border-radius: 1.5rem;
    padding: 2%;
    background: #0062cc;
    color: #fff;
    font-weight: 600;
    width: 50%;
    cursor: pointer;
}
.register .nav-tabs{
    margin-top: 3%;
    border: none;
    background: #0062cc;
    border-radius: 1.5rem;
    width: 28%;
    float: right;
}
.register .nav-tabs .nav-link{
    padding: 2%;
    height: 34px;
    font-weight: 600;
    color: #fff;
    border-top-right-radius: 1.5rem;
    border-bottom-right-radius: 1.5rem;
}
.register .nav-tabs .nav-link:hover{
    border: none;
}
.register .nav-tabs .nav-link.active{
    width: 100px;
    color: #0062cc;
    border: 2px solid #0062cc;
    border-top-left-radius: 1.5rem;
    border-bottom-left-radius: 1.5rem;
}
.register-heading{
    text-align: center;
    margin-top: 8%;
    margin-bottom: -15%;
    color: #0062cc;
}
.default
{
content:"Please select a country";
}


</style>
</head>
<body>

<?php include('ngriHeader.php');  ?>
<div class="container-fluid">
<nav class="navbar navbar-expand-sm bg-info navbar-dark">
  <!-- Brand -->
  <!--<a class="navbar-brand col-md-3 font-acme" href="#"><h5><i class="fas fa-globe"></i> Seismological Data Management Center (SDMC)</h5> </a> -->

  <!-- Links -->
  <ul class="navbar-nav">
    <li class="nav-item">
      <a class="nav-link" href="index.php"><i class="fas fa-home"></i> Home</a>
    </li>
    
 </ul>
</nav>
</div>
<div class="container register">
<div class="signup-form">
<form action="/thermodb/signupnew.php" method="post" name="form1">    
<div class="row">

         <div class="col-md-10 register-right">                            
         <div class="tab-content" id="myTabContent">
         <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
         <h3 class="register-heading">Registration Form</h3>
         <div class="row register-form">
         <div class="col-md-6">
                                        
		<div class="form-group">
                <input type="text" class="form-control" name="FirstName" placeholder="FirstName *"  required="required">
                </div>
		
		<div class="form-group">
                <input type="text" class="form-control" name="UserName" placeholder="UserName *"  required="required">
 		
                </div>	
		<div class="form-group">
                <input type="password" class="form-control"  id="Conpassword" "name="Conpassword" placeholder="Confirm Password *" 			required="required">
                </div>	
		<div class="form-group">
                <input type="text" class="form-control" name="Designation" placeholder="Designation *" required="required">
                </div>
		<div class="form-group">
                <input type="text" class="form-control" name="Address" placeholder="Address *" required="required">
                </div>	
		<div class="form-group">
       		<input type="text" class="form-control" name="State" placeholder="State *" required="required">
        	</div>
		<div class="form-group">
                <input type="tel"  name="Phone" class="form-control" placeholder="Your Phone *" pattern="^\d{10}$" required="required">
                </div>	
                
	</div>
                                        
		<div class="col-md-6">
		<div class="form-group">
                <input type="text" class="form-control" name="LastName" placeholder="LastName *"  required="required">
                </div>
		<div class="form-group">
                <input type="password" class="form-control"  id="Password" name="Password" placeholder="Password *" title="Password must 			contain at least 6 characters, including UPPER/lowercase and numbers." pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}" 			required="required">
		</div>
                <div class="form-group">
                <input type="email" class="form-control" name="Email"  placeholder="Your Email *" required="required">
                </div>                        
                <div class="form-group">
                <input type="text" class="form-control" name="Institute" placeholder="Institute *" required="required">
                </div>	
		<div class="form-group">
        	<input type="text" class="form-control" name="City" placeholder="City/Town/Village *" required="required">
        	</div>			
		<div class="form-group">
          	<select class="form-control select selectpicker countrypicker"  name="Country" data-default="Select Country" >
                 
		</select>
		</div>		
		
	</div>
		<button type="submit" class="btn btn-primary btn center" name="Register" onclick="return Validate()" >Register</button>
		</div>
             	</div>
                </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
		</div>
<script type="text/javascript">
    function Validate() {
        var Password = document.getElementById("Password").value;
        var Confirm_Password = document.getElementById("Conpassword").value;
        if (Password != Confirm_Password) {
            alert("Password and Confirm Password do not match.");
            return false;
        }
        return true;
    }


</script>
<div style="height:50px;"></div>

<div class="container-fluid">
<?php include('footer.php'); ?>
</div>
</body>
</html>

