<!--Main nav bar -->
<div class="container-fluid">
<nav class="navbar navbar-expand-sm bg-info navbar-dark">
  <!-- Brand -->
  <!--<a class="navbar-brand col-md-3 font-acme" href="#"><h5><i class="fas fa-globe"></i> Seismological Data Management Center (SDMC)</h5> </a> -->

  <!-- Links -->
  <ul class="navbar-nav">
    <li class="nav-item">
      <a class="nav-link" href="Admin.php"><i class="fas fa-home"></i> Home</a>
    </li>
    
    <li class="nav-item">
      <a class="nav-link" href="Logout.php"><i class="fas fa-database"></i> Logout</a>
    </li>

<!--
    <li class="nav-item">
      <a class="nav-link" href="contact.php"><i class="fas fa-handshake"></i> Contact us</a>
    </li>
 
   
    <li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
        <i class="fas fa-search-location"></i> Search Catalog
      </a>
      <div class="dropdown-menu">
        <a class="dropdown-item" href="#"><span><i class="fas fa-globe"></i></span> Network Catalog </a>
        <a class="dropdown-item" href="stnCatalog.php"><span><i class="fas fa-globe"></i></span> Station Catalog</a>
        <a class="dropdown-item" href="#"><span><i class="fas fa-globe"></i></span> Earthquake Catalog</a>
      </div>
    </li>  -->
       
  </ul>
</nav>

<div style="height:5px;"></div>
</div>
