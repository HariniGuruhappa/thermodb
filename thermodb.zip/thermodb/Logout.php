<?php
session_start();
?>
<?php
unset($_SESSION["User_Name"]);
unset($_SESSION["Password"]);
 echo '<script>window.location.href = "Login.php";</script>';
?>

