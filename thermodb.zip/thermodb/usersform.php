<?php
require('config/adm_config.php');
?>
<?php   include('mainHeader.php');  ?>
<!-- NGRI Header -->
<?php include('ngriHeader.php');  ?>
<head>
 <link rel="stylesheet" href="./leaflet/leaflet.css"/>
 <script src="./leaflet/leaflet.js" i></script>
  <script src="./leaflet/leaflet.shpfile.js" ></script>
  <script src="./leaflet/shp.js" ></script>
<script src="https://cdn.plot.ly/plotly-latest.min.js"></script>
</head>
<style>
/* Set black background color, white text and some padding */
html,body{
    width:100%;
    height:100%;
    //background-color:#EEDFCC;
}    
footer {
      background-color: #555;
      color: white;
      padding: 15px;
    }
.register{
    padding: 5%;
    margin-top: 3%;
   text-align: center;
}
</style>

<body>
<?php include('admMainLogoutBar.php');  ?>
<div class="row">

<div class="col-lg-7"> </div>
<div class="col-lg-4"><a class="btn btn-danger text-center" href="Admin.php" style="float:right;"> BACK TO SEARCH</a> </div>
</div>
<div class="register">
<?php
$servername = "localhost";
$username = "harini";
$password = "Seis@2019";
$dbname = "Thermodb";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}


// sql to create table

$sql = "SELECT * FROM users_tbl";
$result = $conn->query($sql);


if ($result->num_rows > 0) {
    echo "<table border=2>";
            echo "<tr>";
               
                echo "<th>Firstname</th>";
                echo "<th>Lastname</th>";
		echo "<th>Username</th>";
		echo "<th>Email</th>";
		echo "<th>Designation</th>";
                echo "<th>Institute</th>";
                echo "<th>Is_Admin</th>";
		echo "<th>Is_Active</th>";
            echo "</tr>";
    while($row = $result->fetch_assoc()) {
       echo "<tr>";

                echo "<td>" . $row['First_Name'] . "</td>";
                echo "<td>" . $row['Last_Name'] . "</td>";
		echo "<td>" . $row['User_Name'] . "</td>";
		echo "<td>" . $row['Email_ID'] . "</td>";
		echo "<td>" . $row['Designation'] . "</td>";
		echo "<td>" . $row['Institute'] . "</td>";
		echo "<td>" . $row['Is_Admin'] . "</td>";
		echo "<td>" . $row['Is_Active'] . "</td>";
		echo '<td><a href="Viewuser.php?ID='.$row['User_ID'].'">Edit</a></td>';
            echo "</tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}
$conn->close();
?>
</div>
<?php include('footer.php'); ?>      
</body>

</html>



