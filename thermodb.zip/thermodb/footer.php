<div class="container-fluid footer ">
<?php
$year = date("Y");  
?>
  <div class="text-center">&copy CSIR-NGRI (2019 - <?php echo $year ?>). All rights Reserved.</div> 
  
</div>
