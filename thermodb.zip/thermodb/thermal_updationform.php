<!-- Main Header -->
<?php
// Start the session
session_start();
$user_name=$_SESSION["User_Name"];
?>
<?php   include('mainHeader.php');  ?>

<body>

<!-- NGRI Header -->
<?php include('ngriHeader.php');  ?>
<head>
 <link rel="stylesheet" href="./leaflet/leaflet.css"/>
 <script src="./leaflet/leaflet.js" i></script>
  <script src="./leaflet/leaflet.shpfile.js" ></script>
  <script src="./leaflet/shp.js" ></script>
<script src="https://cdn.plot.ly/plotly-latest.min.js"></script>
<?php include('mainlogoutbar.php');  ?>
</head>
<style>
 /* Set black background color, white text and some padding */

html,body{
    width:100%;
    height:100%;
    //background-color:#EEDFCC;
}

.left1 {
margin-top: 5%;
font-weight: bold;
margin-left:18%;
}
a{

margin-top: 8%;
}
</style>
</head>

<body>
<div class="row">

<div class="col-md-7"> </div>
<div class="col-md-4"><a class="btn btn-danger text-center" href="viewadminDB.php" style="float:right;"> BACK TO SEARCH</a> </div>
</div>

<div class="container-fluid">
  <div class="row">
  <div class = "col-lg-4">
 </div>
<?php
session_start();
$servername = "localhost";
$username = "harini";
$password = "Seis@2019";
$dbname = "Thermodb";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
if(!isset($_GET["id"]))
{
echo "Error";
}
else
{
$id=$_GET["id"];
}
// sql to create table

$sql = "SELECT * FROM thermoinfo_tbl WHERE Borehole_ID=\"$id\"";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
      

		$Borehole_name = $row['Borehole_name'];
		$Borehole_Lat = $row['Borehole_Lat'];
		$Borehole_Long = $row['Borehole_Long'];
		$heatflow = $row['heatflow'];
		$basal_heatflow = $row['basal_heatflow'];
		$thermal_conductivity = $row['thermal_conductivity'];
		$heat_production = $row['heat_production'];
		$crustal_thickness = $row['crustal_thickness'];
		$surface_temperature = $row['surface_temperature'];
		$coeff_of_variability = $row['coeff_of_variability'];
		$corr_length_scale = $row['corr_length_scale'];
		$characteristicdepth = $row['characteristicdepth'];
		$author = $row['author'];
		$author_datetime = $row['author_datetime'];

 }
} else {
    echo "0 results";
}

?>

   <div class="left1">  

     <div class = "col-lg-20">
<!--  <form id="myform" class="form-horizontal" action="/thermodb/thermal_insertionform.php" method="POST" > -->
     <form id="myform" class="form-horizontal" action=""  method="POST" >
        <div class=" form-group row">
  	<label class="col-lg-2.5  col-form-label" for="B_Name">Borehole Name:</label>
     	<div  class="col-lg-5" >
        <input type="text" class="form-control" value='<?php echo $Borehole_name;?>' name="B_Name">
      	</div>

</div>
<br>
   <div class="form-group row">

        <label class="col-lg-2 col-form-label" for="B_Latitude">Latitude:</label>
       <div class="col-lg-4">
       <input type="text" class="form-control" value='<?php echo $Borehole_Lat;?>' name="B_Latitude">
       </div>

	<label class="col-lg-2 col-form-label" for="B_Longitude">Longitude:</label>
      	<div class="col-lg-4">
        <input type="datetime" class="form-control" value='<?php echo $Borehole_Long;?>' name="B_Longitude">
        </div>
  
      
</div>
<br>
	
     	<div class="form-group row">
	<label class="col-lg-2 col-form-label" for="B_heatflow">Heatflow:</label>
      	 <div class="col-lg-4">
        <input type="text" class="form-control" value='<?php echo $heatflow;?>' name="B_heatflow">
      	</div>	

       <label class="col-lg-2 col-form-label" for="basal_heatflow">Basal Heatflow:</label>
       <div class="col-lg-4">
       <input type="text" class="form-control" value='<?php echo $basal_heatflow;?>' name="basal_heatflow">
       </div>
</div>

<br>
	<div class="form-group row">
	<label class="col-lg-2 col-form-label" for="thermal_conductivity">Thermal Conductivity:</label>
      	 <div class="col-lg-4">
        <input type="text" class="form-control" value='<?php echo $thermal_conductivity;?>' name="thermal_conductivity">
      	</div>	

       <label class="col-lg-2 col-form-label" for="heat_production">Heat Production:</label>
       <div class="col-lg-4">
       <input type="text" class="form-control" value='<?php echo $heat_production;?>' name="heat_production">
       </div>
</div>

<br>
	<div class="form-group row">
	<label class="col-lg-2 col-form-label" for="crustal_thickness">Crustal Thickness:</label>
      	 <div class="col-lg-4">
        <input type="text" class="form-control" value='<?php echo $crustal_thickness;?>' name="crustal_thickness">
      	</div>	

       <label class="col-lg-2 col-form-label" for="surface_temperature">Surface Temperature:</label>
       <div class="col-lg-4">
       <input type="text" class="form-control" value='<?php echo $surface_temperature;?>' name="surface_temperature">
       </div>
</div>

<br>
	<div class="form-group row">
	<label class="col-lg-2 col-form-label" for="c_o_v">Coeff. of Variability:</label>
      	 <div class="col-lg-4">
        <input type="text" class="form-control" value='<?php echo $coeff_of_variability;?>' name="c_o_v" required="required">
      	</div>	

       <label class="col-lg-2 col-form-label" for="c_l_s">Corr. Length Scale:</label>
       <div class="col-lg-4">
       <input type="text" class="form-control" value='<?php echo $corr_length_scale;?>' name="c_l_s" required="required">
       </div>
</div>

<br>
	<div class="form-group row">
	<label class="col-lg-2 col-form-label" for="characteristic_depth">Characteristic Depth:</label>
      	 <div class="col-lg-4">
        <input type="text" class="form-control" value='<?php echo $characteristicdepth;?>' name="characteristic_depth" required="required">
      	</div>
<!--
<label class="col-lg-2 col-form-label" for="author">Author:</label>
      	 <div class="col-lg-4">
        <input type="text" class="form-control" value='<?php echo $author;?>' name="author" required="required">
      	</div>		-->
</div>

<br>
	<div class="form-group row">
	

  <!--     <label class="col-lg-2 col-form-label" for="authordatetime">Author Datetime:</label>
     	<div class="col-lg-4">
       <input type="text" class="form-control" value='<?php echo $author_datetime;?>'
	 name="authordatetime" required="required"> -->
 	
    	</div>
</div>

<br>
<div class="form-group row"> 
<div class="col-lg-8">    
 <button type="submit" class="btn btn-primary mb-2" name="update">update</button>
</div>
</div>
</div>


</form>

</div>        
</div>
</div>   
</div>
<div style="height:50px;"></div>

<div class="container-fluid">
<?php include('footer.php'); ?>
</div>
</body>
</html>
<?php
$Borehole_name = $_POST['B_Name'];
$Borehole_Lat = $_POST['B_Latitude'];
$Borehole_Long = $_POST['B_Longitude'];
$heatflow = $_POST['B_heatflow'];
$basal_heatflow = $_POST['basal_heatflow'];
$thermal_conductivity = $_POST['thermal_conductivity'];
$heat_production = $_POST['heat_production'];
$crustal_thickness = $_POST['crustal_thickness'];
$surface_temperature = $_POST['surface_temperature'];
$coeff_of_variability = $_POST['c_o_v'];
$corr_length_scale = $_POST['c_l_s'];
$characteristicdepth = $_POST['characteristic_depth'];
$author = $user_name;
/*$author_datetime = $_POST['autordatetime'];*/


if(isset($_POST['update'])){

		
$sql = "UPDATE thermoinfo_tbl SET Borehole_name='$Borehole_name',
Borehole_Lat='$Borehole_Latitude',Borehole_Long='$Borehole_Longitude',heatflow='$heatflow',basal_heatflow='$basal_heatflow',  
thermal_conductivity='$thermal_conductivity', heat_production='$heat_production', crustal_thickness='$crustal_thickness', 
surface_temperature='$surface_temperature', coeff_of_variability='$coeff_of_variability', corr_length_scale='$corr_length_scale', 
characteristicdepth='$characteristicdepth', mod_author='$author', mod_datetime_author=NOW() WHERE Borehole_ID=\"$id\"";

echo $sql;

if (mysqli_query($conn, $sql)) {
    echo '<script language="javascript">alert("Updated Successfully");</script>';
} else {
    echo "Error creating table: " . mysqli_error($conn);
}


$conn->close();
} 
?>

 
 
