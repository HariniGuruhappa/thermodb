<?php
// Start the session
session_start();
if(!$_SESSION["User_Name"])
{
echo '<script>window.location.href = "Login.php?pg=0";</script>';
}
else
{
if($_SESSION["Is_Active"] && $_SESSION["Is_Admin"])
$varok="OK";
else
{
echo 'You are not authorized to view this page!';
sleep(10);
echo '<script>window.location.href = "Login.php?pg=0";</script>';
}

}


?>
