<?php
// Start the session
session_start();
?>
<?php
$servername = "localhost";
$username = "harini";
$password = "Seis@2019";
$dbname = "Thermodb";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$id2=$_GET["ID"];

if(isset($_POST['update']))
{




		$Firstname=$_POST['FirstName'];
		$Lastname=$_POST['LastName'];
		$Username=$_POST['UserName'];
		$Email=$_POST['Email'];
		$Designation=$_POST['Designation'];
		$Institute=$_POST['Institute'];
		$Is_Admin=$_POST['Is_Admin'];
		$Is_Active=$_POST['Is_Active'];
		$sendmail=$_POST['sendmail'];

		
$sql = "UPDATE users_tbl SET First_Name='$Firstname',
Last_Name='$Lastname',User_Name='$Username',Email_ID='$Email',Designation='$Designation',
Institute='$Institute',Is_Admin='$Is_Admin',Is_Active='$Is_Active',sendmail='$sendmail' WHERE User_ID=$id2";
}

echo $sql;
if (mysqli_query($conn, $sql)) {
    echo '<script language="javascript">alert("Updated Successfully");</script>';
$sql = "SELECT Email_ID,Last_Name,Is_Active,sendmail FROM users_tbl WHERE User_ID=$id2";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
		$Is_Active=$row['Is_Active'];
		$sendmail=$row['sendmail'];
	        $Email_ID=$row['Email_ID'];
		$Last_Name=$row['Last_Name'];
 }
} else {
    echo "0 results";
}
if($sendmail==0 && $Is_Active=="TRUE")
header("Location: http://172.27.20.119/thermodb/sendusermail.php?Email=$Email_ID&uname=$Last_Name");
} else {
    echo "Error: " . mysqli_error($conn);
}

$conn->close();
?>


