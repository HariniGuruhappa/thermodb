<div class="col-md-3">
<div class="card">
  
 <div class="card-body sidebar-color sideBar ">
 <h3 class="font-limelight "><i class="fas fa-list-ul"></i> Quick Links </h3> 

 <ul>
 <li><a href="index.php"><span><i class="fas fa-home"></i></span> Home</a></li>
<li><a href="networkCatalog.php"><span><i class="fas fa-globe"></i></span> Network Info </a></li>
<li><a href="stnCatalog.php"><span><i class="fas fa-globe"></i></span> Station Info </a> </li>
<li><a href="eventInfo.php"><span><i class="fas fa-globe"></i></span> Earthquake Catalog </a></li>
<!-- <li><a href="#"><span><i class="fas fa-globe"></i></span> Recent Earthquakes </a></li> -->
</ul>
 
 </div> 
</div>


</div>
