<!-- Main Header -->
<?php
// Start the session
session_start();
?>
<?php   include('mainHeader.php');  ?>

<body>

<!-- NGRI Header -->
<?php include('ngriHeader.php');  ?>
<head>
 <link rel="stylesheet" href="./leaflet/leaflet.css"/>
 <script src="./leaflet/leaflet.js" i></script>
  <script src="./leaflet/leaflet.shpfile.js" ></script>
  <script src="./leaflet/shp.js" ></script>
<script src="https://cdn.plot.ly/plotly-latest.min.js"></script>
<?php include('mainlogoutbar.php');  ?>
</head>
<style>
 /* Set black background color, white text and some padding */
html,body{
    width:100%;
    height:100%;
}
.left1 {
margin-top: 7%;
font-weight: bold;
margin-left:2%;
}
.left
{
margin-top:0px;

}
a{

margin-top: 8%;
}
</style>
</head>

<body>

  
<div class="row">

<div class="col-md-7"> </div>
<div class="col-md-4"><a class="btn btn-danger text-center" href="viewadminheatflow.php" style="float:right;"> BACK TO SEARCH</a> </div>
</div>
  
<div class="container-fluid">
  <div class="row">
  <div class = "col-lg-4">
<div class="left">
   
</div>   
</div>
<?php

$servername = "localhost";
$username = "harini";
$password = "Seis@2019";
$dbname = "Thermodb";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
if(!isset($_GET["id"]))
{
echo "Error";
}
else
{
$id=$_GET["id"];
}
// sql to create table

$sql = "SELECT * FROM heatflowdata_tbl WHERE Location_ID=\"$id\"";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
      

		$Location_name=$row['Location_name'];
		$Latitude=$row['Latitude'];
		$Longitude=$row['Longitude'];
		$heatflow=$row['heatflow'];
		 }
} else {
    echo "0 results";
}

?>


<div class="left1">  
<div class = "col-lg-12">
     <form id="myform" class="form-horizontal" action="/thermodb/heatflow_insertionform.php" method="POST" >
     

   	<div class=" form-group row">
  	<label class="col-lg-2.5  col-form-label for="Loc_Name">Location Name:</label>
     	<div  class="col-lg-5" >
        <input type="text" class="form-control" id="Loc_Name" name="Loc_Name" value='<?php echo $Location_name;?>'>
      	</div>
      
	
</div>
<br>
   <div class="form-group row">
	<label class="col-lg-1.5 col-form-label" for="Loc_Latitude">Latitude:</label>
      	<div class="col-lg-4">
        <input type="datetime" class="form-control" id="Loc_Latitude" name="Loc_Latitude" value='<?php echo $Latitude;?>'>
        </div>
  
       <label class="col-lg-1.5 col-form-label" for="Loc_Longitude">Longitude:
	</label>
       <div class="col-lg-4">
       <input type="text" class="form-control" id="Loc_Longitude" name="Loc_Longitude" 
      value='<?php echo $Longitude;?>'>
       </div>
</div>
<br>
	
     	<div class="form-group row">
	<label class="col-lg-2.5 col-form-label" for="Loc_heatflow">HeatFlow Value:</label>
      	 <div class="col-lg-5">
        <input type="text" class="form-control" id="Loc_heatflow" name="Loc_heatflow"
         value='<?php echo $heatflow;?>'
      	</div>	
</div>
</div>
<br>
<div class="form-group row"> 
<div class="col-lg-8">    
 <button type="submit" class="btn btn-primary mb-2" name="update">update</button>
</div>
</div>



</form>
</div>
 </div>
</div>        
</div>
<?php

		$Location_name=$_POST['Loc_Name'];
		$Latitude=$_POST['Loc_Latitude'];
		$Longitude=$_POST['Loc_Longitude'];
		$heatflow=$_POST['Loc_heatflow'];
		

if(isset($_POST['update'])){

		
$sql = "UPDATE heatflowdata_tbl SET Location_name= NULLIF('$Location_name',''),
Latitude='$Latitude',Longitude='$Longitude',heatflow='$heatflow' WHERE Location_ID=\"$id\"";

if (mysqli_query($conn, $sql)) {
    echo '<script language="javascript">alert("Updated Successfully");</script>';
} else {
    echo "Error creating table: " . mysqli_error($conn);
}

$conn->close();
}
?>
<div style="height:50px;"></div>

<div class="container-fluid">
<?php include('footer.php'); ?>
</div>

 </body>
</html> 
 






