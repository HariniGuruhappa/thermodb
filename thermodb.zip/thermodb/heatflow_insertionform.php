<!-- Main Header -->
<?php
require('config/adm_config.php');
?>

 <?php   include('mainHeader.php');  ?>

<body>

<!-- NGRI Header -->
<?php include('ngriHeader.php');  ?>
<head>
 <link rel="stylesheet" href="./leaflet/leaflet.css"/>
 <script src="./leaflet/leaflet.js" i></script>
  <script src="./leaflet/leaflet.shpfile.js" ></script>
  <script src="./leaflet/shp.js" ></script>
<script src="https://cdn.plot.ly/plotly-latest.min.js"></script>
</head>
<style>
 /* Set black background color, white text and some padding */
html,body{
    width:100%;
    height:100%;
    //background-color:#EEDFCC;
}
.left1 {
margin-top: 7%;
font-weight: bold;
margin-left:9%;
}
.left
{
margin-top:0px;

}
a{

margin-top: 8%;
}
</style>
</head>

<body>
<?php include('admMainLogoutBar.php');  ?>
  
<div class="row">

<div class="col-md-7"> </div>
<div class="col-md-4"><a class="btn btn-danger text-center" href="Admin.php" style="float:right;"> BACK TO SEARCH</a> </div>
</div>

<div class="left">  
<div class="container-fluid">
<div class="row">
<div class = "col-lg-3">
  </div>
   <div class="left1">  


     <form id="myform" class="form-horizontal" action="/thermodb/heatflow_insertionform.php" method="POST" >
     

   	<div class=" form-group row">
  	<label class="col-lg-2.5  col-form-label for="Loc_Name">Location Name:</label>
     	<div  class="col-lg-5" >
        <input type="text" class="form-control" id="Loc_Name" placeholder="Enter Loc_Name" name="Loc_Name" required="required">
      	</div>
      
	
</div>
<br>
   <div class="form-group row">
	<label class="col-lg-1.5 col-form-label" for="Loc_Latitude">Latitude:</label>
      	<div class="col-lg-4">
        <input type="datetime" class="form-control" id="Loc_Latitude" placeholder="Enter Loc_Latitude" name="Loc_Latitude" required="required">
        </div>
  
       <label class="col-lg-1.5 col-form-label" for="Loc_Longitude">Longitude:
	</label>
       <div class="col-lg-4">
       <input type="text" class="form-control" id="Loc_Longitude" 
       placeholder="Enter Loc_Longitude" name="Loc_Longitude" required="required">
       </div>
</div>
<br>
	
     	<div class="form-group row">
	<label class="col-lg-2.5 col-form-label" for="Loc_heatflow">HeatFlow Value:</label>
      	 <div class="col-lg-5">
        <input type="text" class="form-control" id="Loc_heatflow" 
	placeholder="Enter Loc_heatflow" name="Loc_heatflow" required="required">
      	</div>	
     
      	
 </div>

<br><br>
<div class="form-group row"> 
<div class="col-lg-8">    
 <center><button type="submit" class="btn btn-primary mb-2" name="submit">submit</button></center>
</div>
</div>
</div>
</div>

</form>
</div>
 </div>

<?php include('footer.php'); ?>      
</div>
</body>
</html>
<?php

$servername = "localhost";
$username = "harini";
$password = "Seis@2019";
$dbname = "Thermodb";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
if(isset($_POST['submit']))
{

$Location_name = $_POST['Loc_Name'];
$Latitude = $_POST['Loc_Latitude'];
$Longitude = $_POST['Loc_Longitude'];
$heatflow = $_POST['Loc_heatflow'];



$sql = "INSERT INTO heatflowdata_tbl (Location_name, Latitude, Longitude, heatflow) VALUES (NULLIF('$Location_name',''),NULLIF('$Latitude',''),NULLIF('$Longitude',''),NULLIF('$heatflow',''))";


if ($conn->query($sql) ==TRUE) {
    echo '<script language="javascript">alert("Added Successfully");</script>';
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
}
?> 











