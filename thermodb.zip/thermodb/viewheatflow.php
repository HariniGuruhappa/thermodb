<!-- Main Header -->
<?php
// Start the session
session_start();
if (!$_SESSION["User_Name"])
{
 echo '<script>window.location.href = "Login.php?pg=2";</script>';
}

?>
<?php   include('mainHeader.php');  ?>

<body>

<!-- NGRI Header -->
<?php include('ngriHeader.php');  ?>
<head>
 <link rel="stylesheet" href="./leaflet/leaflet.css"/>
 <script src="./leaflet/leaflet.js" i></script>
  <script src="./leaflet/leaflet.shpfile.js" ></script>
  <script src="./leaflet/shp.js" ></script>
<script src="https://cdn.plot.ly/plotly-latest.min.js"></script>
<style>
html,body{
    width:100%;
    height:100%;
}
h5
{
margin-top:1%;
font-weight: bold;
font-family:italic;
font-size:30px;
 color: gray;
}
p {
  
  margin-left: 15%;
 margin-top: 2%;
 
}
</style>
</head>
<!-- SEIS Header -->
<!--Main nav bar -->
<div class="container-fluid">

<?php include('usrMainLogoutBar.php'); ?>

<div style="height:5px;"></div>
</div>


<div class="container-fluid">




<?php
require('./config/config.php');

$sql = "SELECT Location_ID,Location_name,Latitude,Longitude,heatflow FROM  heatflowdata_tbl";
     
//echo $sql;

$result = $conn->query($sql);

$f=0;
echo '<script> var  hplanes = [';
if ($result->num_rows > 0) {
    // output data of each row

 while($row = $result->fetch_assoc()) {

  if (! empty($row["Latitude"]) && !empty($row["Longitude"]))
    echo '["'.$row["Location_name"].'",'.$row["Latitude"].','.$row["Longitude"].','.$row["Location_ID"].','.$row["heatflow"].'],';

$f++;
    }
} 
echo '];';
 
echo '</script>';

?>
<div class="row">

<div class="col-lg-6">

<div id="map1" style="width: 100%; height: 800px"></div>
</div>


<div class="col-lg-6">
<h5>Heat Flow Map of India </h5>

<div id="stnId">
<h4 class="font-acme" style="color:red;padding-top:80px;padding-left:10px;">Clik on the location to see the Heat Flow Value! </h4>
</div>

<div id="stnInfo">


</div>

</div> <!-- End of table -->


</div>

<div class="row">
<div id="plotInfo"> </div>

</div>


</div> <!-- End of Container -->

<?php

if(isset($_GET['id']))
{
echo '<script  type="text/javascript">';
echo ' $( document ).ready(function() {';
echo '  circleClick('.$_GET['id'].',null);';
echo '}); </script>';
}

?>



<div style="height:50px;"></div>

<div class="container-fluid">
<?php include('footer.php'); ?>
</div>





<script src="Leaflet.SvgShapeMarkers-gh-pages/dist/leaflet-svg-shape-markers.min.js"></script>

<script>
function polystyle(feature) {
    return {
        fillColor: 'white',
        weight: 2,
        opacity: 1,
        color: 'red',  //Outline color
        fillOpacity: 0.7
    };
}


var mymap = L.map('map1', {
			center: [22, 82],
			zoom: 4.5
		});

var polyIndia = JSON.parse($.ajax({'url': "./India/polyIndia.json", 'async': false}).responseText); 

var poly = L.polygon(polyIndia, {
    color: 'black',
    fillColor: '#fff',
    fillOpacity: 0.1,
     weight: 1.5,
 }).addTo(mymap);


	L.tileLayer('https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token=pk.eyJ1IjoibWFwYm94IiwiYSI6ImNpejY4NXVycTA2emYycXBndHRqcmZ3N3gifQ.rJcFIG214AriISLbB6B5aw', {
		maxZoom: 18,
		attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, ' +
			'<a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, ' +
			'Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
		id: 'mapbox.streets'
	}).addTo(mymap);


var LeafIcon = L.Icon.extend({
		options: {
			//shadowUrl: 'icons/triangle-red.png',
			iconSize:     [28, 25],
			//shadowSize:   [50, 64],
			iconAnchor:   [22, 94],
			//shadowAnchor: [4, 62],
			popupAnchor:  [-3, -76]
		}
	});


var greenIcon = new LeafIcon({iconUrl: 'icons/triangle-red.png'});


for (var i = 0; i < hplanes.length; i++) {
			
 var triangle = L.shapeMarker([hplanes[i][1],hplanes[i][2]], {
		fillColor: "red",
                fillOpacity: 0.9,
		color: "red",
		shape: "circle",
		radius: 3
	}).bindPopup("Location: "+hplanes[i][0]+"<br>  Heatflow : "+hplanes[i][4]+" mW/m<sup>2</sup>")
  	  .on('click', circleClick.bind(null,hplanes[i][3] ))
          .addTo(mymap); }

function circleClick(b,e)
{
//alert(b);

$('#plotInfo').html('');

 $.ajax({
        method: "GET", url: "api/api1.php?id="+b, 
        }).done(function( data ) {
        var result = $.parseJSON(data);
        var string = '<table class=\"table table-hover table-bordered\">';
        length = result.length;
        var stnName;
  $.each( result, function( key, value ) {
      stnName=value['Location_name'];
     string += "<tr><td>Location Name</td><td>"+value['Location_name']+ "</td></tr>";
     string += "<tr><td>Latitude (<sup>o</sup>N) </td><td> "+ value['Latitude']+"</td> </tr>";
     string += "<tr><td>Longitude (<sup>o</sup>E) </td><td> "+ value['Longitude']+"</td> </tr>";
     string += "<tr><td>Heat Flow (mW/m<sup>2</sup>) </td><td> "+ value['heatflow']+"</td> </tr>";  
     
      });
    
    string += '</table>';



    $('#stnId h4').html("Search Results for Thermal Data: "+stnName+"");

    $("#stnInfo").html(string);


    

     
    
      });


 $.ajax({
        method: "GET", url: "api/mapapi1.php?id="+b, 
        }).done(function( data ) {
      
       });


}





// string += '<a class="btn btn-sm btn-warning" href="heatflow_updationform.php?id='+hplanes[3]+'">Update Thermal Data</a>';

//     $('#stnId h4').html("Search Results for Thermal Data: "+stnName+"");

//    $("#stnInfo").html(string);

</script>

</div>
</body>
</html>
