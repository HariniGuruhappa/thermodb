<div class="container-fluid">
<div class="jumbotron">


<!-- <img src="images/bg2.png"></img>  -->

<h1> THERMAL DATABASE FOR THE INDIAN REGION </h1>
</div>
</div>
