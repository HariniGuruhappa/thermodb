
<?php
session_start();
// Import PHPMailer classes into the global namespace
// These must be at the top of your script, not inside a function
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
if(!isset($_GET["uid"]))
{
echo "Error";
}
else
{
$User=$_GET["uid"];
}
$servername = "localhost";
$username = "harini";
$password = "Seis@2019";
$dbname = "Thermodb";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$sql = "SELECT Last_Name,User_ID,Email_ID FROM users_tbl WHERE User_Name=\"$User\"";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
      
		$User_ID=$row['User_ID'];
		$Email_ID=$row['Email_ID'];
		$Last_Name=$row['Last_Name'];
		 }
} else {
    echo "0 results";
}

//echo "$User_ID,$Email_ID,$Last_Name";

// Load Composer's autoloader
require '../vendor/autoload.php';

// Instantiation and passing `true` enables exceptions
$mail = new PHPMailer(true);

try {
    //Server settings
    $mail->SMTPDebug = SMTP::DEBUG_SERVER;                      // Enable verbose debug output
    $mail->isSMTP();                                            // Send using SMTP
    $mail->Host       = 'smtp.gmail.com';                    // Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
    $mail->Username   = 'thermaldb.epm@gmail.com';                     // SMTP username
    $mail->Password   = 'NGRI@123';                               // SMTP password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;         // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` also accepted
    $mail->Port       = 587;                                    // TCP port to connect to

    //Recipients
    $mail->setFrom('thermaldb.epm@gmail.com', 'Thermodb');
//Receipients email address can be provided below
    $mail->addAddress('thermaldb.epm@gmail.com', 'Thermodb');     // Add a recipient
 //   $mail->addReplyTo('info@example.com', 'Information');
   $mail->addCC('g.harini07@gmail.com');
 //   $mail->addBCC('bcc@example.com');

    // Attachments
 //   $mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
 //   $mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name

    // Content
    $mail->isHTML(true);                                  // Set email format to HTML
    $mail->Subject = 'Approve User for '.$User.'';
    $mail->Body    = '<a href="http://172.27.20.119/thermodb/Viewuser.php?ID='.$User_ID.'">Click here to view and approve the user</a>';
    $mail->AltBody = 'User Approval';

    $mail->send();

    echo 'Message has been sent';
//header("Location: http://172.27.20.119/thermodb/sendusermail.php?Email=$Email_ID&uname=$Last_Name");
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}
?>
