<?php

// 1) Connect to mysql database
include('../config/config.php');


$id=$_GET['id'];

$sql = "SELECT DISTINCT *  FROM thermoinfo_tbl  WHERE Borehole_ID=$id";

$result = $conn->query($sql);

if(! $result ) {
        die('Could not get data: ' . mysql_error());
     }

while($row1 = mysqli_fetch_assoc($result)) {
    $command='cd /var/www/html/thermodb/maps/ ; /usr/bin/octave  --eval "lithophpfinal( '.$row1['crustal_thickness'].','.$row1['basal_heatflow'].','.$row1['corr_length_scale'].','.$row1['coeff_of_variability'].','.$row1['surface_temperature'].','.$row1['thermal_conductivity'].','.$row1['characteristicdepth'].','.$row1['heat_production'].','.$row1['Borehole_ID'].')"';
}

shell_exec($command);

echo $command;

?>

