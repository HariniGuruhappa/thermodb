<?php

// 1) Connect to mysql database
include('../config/config.php');


$id=$_GET['id'];

$sql = "SELECT DISTINCT *  FROM heatflowdata_tbl  WHERE Location_ID=$id";

$result = $conn->query($sql);

if(! $result ) {
        die('Could not get data: ' . mysql_error());
     }

while($row1 = mysqli_fetch_assoc($result)) {

  $command='( '.$row1['Location_name'].','.$row1['Latitude'].','.$row1['Longitude'].','.$row1['heatflow'].')';

                
}

shell_exec($command);

echo $command;

?>

