<!-- Main Header -->
<?php   include('mainHeader.php');  ?>

<body>

<!-- NGRI Header -->
<?php include('ngriHeader.php');  ?>
<head>
 <link rel="stylesheet" href="./leaflet/leaflet.css"/>
 <script src="./leaflet/leaflet.js" i></script>
  <script src="./leaflet/leaflet.shpfile.js" ></script>
  <script src="./leaflet/shp.js" ></script>
<script src="https://cdn.plot.ly/plotly-latest.min.js"></script>
</head>
<!-- SEIS Header -->
<?php include('mainSeisNavBar.php'); ?>

<div class="container-fluid">



<div class="container" style="min-height:70vh;" >

<div class="row">

<div class="col-md-8">
<img src="images/india_Map.png"></img>
 </div>

<div class="col-md-4" style="text-align:justify;padding:10px 10px 10px 10px;">

<h4> <strong>About Us! <strong></h4>
<br>
<h5>
<p>A Web-based database system is designed and implemented which brings out the heat flow map and the thermal structure for the Indian region.</p>
<p> The database comprises of two tables one is the heat flow information such as Location name, Latitude, Longitude and the heat flow values at almost 170 locations in the Indian region.</p>
<p> The second table consist of thermal parameters such as Location name, Latitude, Longitude, Thermal Conductivity, Heat Production, Heat flow and Crustal Thickness which are used to obtain the thermal structure at the locations.</p><h5>  

</div>




</div> <!-- End of Row -->

</div> <!-- End of Container -->

</div> <!-- End of Container Fluid-->

<div style="height:50px;"></div>

<div class="container-fluid">
<?php include('footer.php'); ?>
</div>

</body>
</html>

