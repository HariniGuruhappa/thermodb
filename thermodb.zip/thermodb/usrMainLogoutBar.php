<nav class="navbar navbar-expand-sm bg-info navbar-dark">
  <!-- Brand -->
  <!--<a class="navbar-brand col-md-3 font-acme" href="#"><h5><i class="fas fa-globe"></i> Seismological Data Management Center (SDMC)</h5> </a> -->

  <!-- Links -->
  <ul class="navbar-nav">
    <li class="nav-item">
      <a class="nav-link" href="index.php"><span><i class="fas fa-home"></i></span> Home</a>
    </li>
 
 <li class="nav-item">
      <a class="nav-link" href="viewDB.php"><span><i class="fas fa-database"></i></span> View Temperature Profiles</a>
    </li>

    <li class="nav-item">
      <a class="nav-link" href="viewheatflow.php"><span><i class="fas fa-database"></i></span> View Heat Flow</a>
    </li>



    <li class="nav-item">
      <a class="nav-link" href="Logout.php"><i class="fas fa-database"></i> Logout</a>
    </li>


  </ul>
</nav>

