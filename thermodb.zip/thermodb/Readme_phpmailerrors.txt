if we recieve permission denied errors after sendin mail in browser

$ getsebool httpd_can_sendmail
if it shows: httpd_can_sendmail --> off
$ sudo setsebool -P httpd_can_sendmail 1
$ getsebool httpd_can_network_connect
if it shows:httpd_can_network_connect --> off
$ sudo setsebool -P httpd_can_network_connect 1


A bit late, but perhaps someone will find it useful.

Links that fix the problem (you must be logged into google account):

https://security.google.com/settings/security/activity?hl=en&pli=1

https://www.google.com/settings/u/1/security/lesssecureapps

https://accounts.google.com/b/0/DisplayUnlockCaptcha

Some explanation of what happens:

This problem can be caused by either 'less secure' applications trying to use the email account (this is according to google help, not sure how they judge what is secure and what is not) OR if you are trying to login several time in a row OR if you change countries (for example use VPN, move code to different server or actually try to login from different part of the world).

To resolve I had to: (first time)

login to my account via web
view recent attempts to use the account and accept suspicious access: THIS LINK
https://security.google.com/settings/security/activity?hl=en&pli=1
disable the feature of blocking suspicious apps/technologies: THIS LINK
https://www.google.com/settings/u/1/security/lesssecureapps
This worked the first time, but few hours later, probably because I was doing a lot of testing the problem reappeared and was not fixable using the above method. In addition I had to clear the captcha (the funny picture, which asks you to rewrite a word or a sentence when logging into any account nowadays too many times) :

after login to my account I went HERE

https://accounts.google.com/b/0/DisplayUnlockCaptcha
Clicked continue
