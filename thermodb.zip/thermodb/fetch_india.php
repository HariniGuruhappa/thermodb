<?php

if ($fh = fopen('India/India_boundary.dat', 'r')) {
    while (!feof($fh)) {
        $line = fgets($fh);
       // echo $line;
        
        $str=explode(",",$line);
          echo '['.$str[1].','.$str[0].'],';
       echo "<br>";
          
    }
    fclose($fh);
}

?>
