<?php
// Start the session
session_start();
?>
<?php
$servername = "localhost";
$username = "harini";
$password = "Seis@2019";
$dbname = "Thermodb";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
if(isset($_POST['Register']))
{
$Firstname = $_POST['FirstName'];
$Lastname = $_POST['LastName'];
$Username = $_POST['UserName'];
$Password = md5($_POST['Password']);
$Email = $_POST['Email'];
$Designation = $_POST['Designation'];
$Institute = $_POST['Institute'];
$Address = $_POST['Address'];
$City = $_POST['City'];
$State = $_POST['State'];
$Country = $_POST['Country'];
$Phone_Number = $_POST['Phone'];



$sql = "INSERT INTO users_tbl (First_Name, Last_Name,User_Name, Password,Email_ID,Designation, Institute,Address,City,State,Country,phone) VALUES ('$Firstname','$Lastname','$Username','$Password','$Email','$Designation','$Institute','$Address','$City','$State','$Country','$Phone_Number')";

if ($conn->query($sql) ==TRUE) {
    echo '<script language="javascript">alert("Pending For Admin Approval");</script>';
header("Location: sendadminmail.php?uid=$Username");
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
}
?>
