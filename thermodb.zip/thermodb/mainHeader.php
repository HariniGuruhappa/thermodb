
<!DOCTYPE html>
<html lang="en">
<head>
  <title>India-Thermal Structure</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="./bootstrap/v4.2.1/css/bootstrap.min.css">
  
  <link rel="stylesheet" href="./fontawesome/v5.7.0/css/all.css"> 
  <link rel="stylesheet" href="./datetime/v4.1/css/bootstrap-datepicker.min.css">
  <link rel="stylesheet" href="./css/seis.css">
<!-- <link rel="stylesheet" type="text/css" href="datatables/v1.10.16/css/dataTables.bootstrap4.min.css">
 <link rel="stylesheet" type="text/css" href="datatables/v1.10.16/css/buttons.dataTables.min.css"> -->

  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Tangerine">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Acme">
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/bs4/dt-1.10.18/datatables.min.css"/>
 
  <!--<script src="./jquery/v3.3.1/jquery.min.js"></script>-->
 <script type="text/javascript" language="javascript" src="https://code.jquery.com/jquery-3.3.1.js"></script>
  <script src="./popper/v1.14.6/popper.min.js"></script>
  <script src="./bootstrap/v4.2.1/js/bootstrap.min.js"></script>
  <script src="./datetime/v4.1/js/bootstrap-datepicker.min.js"></script>
<!--  <script type="text/javascript" language="javascript" src="datatables/v1.10.16/js/jquery.dataTables.min.js"></script>
  <script type="text/javascript" language="javascript" src="datatables/v1.10.16/js/dataTables.bootstrap4.min.js"></script>
  <script type="text/javascript" language="javascript" src="datatables/v1.10.16/js/dataTables.buttons.min.js"></script>
  <script type="text/javascript" language="javascript" src="datatables/v1.10.16/js/buttons.flash.min.js"></script> -->
  <script type="text/javascript" language="javascript" src="datatables/v1.10.16/js/jszip.min.js"> </script>
  <script type="text/javascript" language="javascript" src="datatables/v1.10.16/js/pdfmake.min.js"></script>
  <script type="text/javascript" language="javascript" src="datatables/v1.10.16/js/vfs_fonts.js"></script>
<!--  <script type="text/javascript" language="javascript" src="datatables/v1.10.16/js/buttons.html5.min.js"></script>
  <script type="text/javascript" language="javascript" src="datatables/v1.10.16/js/buttons.print.min.js"></script> -->
 
<script type="text/javascript" src="https://cdn.datatables.net/v/bs4/dt-1.10.18/datatables.min.js"></script>
</head>
